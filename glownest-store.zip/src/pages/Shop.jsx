import React from "react";
import { Button } from "@/components/ui/button";

const products = [
  { name: "Herbal Face Wash", price: "₹249", image: "/images/facewash.jpg" },
  { name: "Organic Lip Balm", price: "₹199", image: "/images/lipbalm.jpg" },
];

export default function Shop() {
  return (
    <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 bg-[#F5F3EA] min-h-screen">
      {products.map((product, idx) => (
        <div key={idx} className="rounded-2xl shadow-md hover:scale-105 transition-transform bg-white">
          <img src={product.image} alt={product.name} className="rounded-t-2xl w-full h-48 object-cover" />
          <div className="p-4 text-center">
            <h2 className="text-lg font-semibold text-[#333] mb-2">{product.name}</h2>
            <p className="text-[#666] mb-3">{product.price}</p>
            <Button className="bg-[#A3B18A] hover:bg-[#8DA57F] text-white w-full">Add to Cart</Button>
          </div>
        </div>
      ))}
    </div>
  );
}