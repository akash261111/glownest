import React, { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Checkout() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "" });
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];
  const total = cartItems.reduce((acc, item) => acc + parseFloat(item.price.replace("₹", "")), 0);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const loadRazorpay = () => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onerror = () => alert("Failed to load Razorpay SDK.");
    script.onload = () => handlePayment();
    document.body.appendChild(script);
  };

  const handlePayment = () => {
    const options = {
      key: "rzp_test_1234567890", // Replace with your Razorpay key
      amount: total * 100,
      currency: "INR",
      name: "GlowNest",
      description: "Order Payment",
      handler: function (response) {
        alert("Payment successful! ID: " + response.razorpay_payment_id);
        localStorage.removeItem("cart");
        window.location.href = "/";
      },
      prefill: {
        name: form.name,
        email: form.email,
        contact: form.phone,
      },
      theme: { color: "#A3B18A" },
    };
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || !form.address) {
      alert("Please fill all fields");
      return;
    }
    loadRazorpay();
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Checkout</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="name" placeholder="Full Name" className="w-full p-2 border rounded" value={form.name} onChange={handleChange} />
        <input name="email" placeholder="Email" className="w-full p-2 border rounded" value={form.email} onChange={handleChange} />
        <input name="phone" placeholder="Phone" className="w-full p-2 border rounded" value={form.phone} onChange={handleChange} />
        <textarea name="address" placeholder="Shipping Address" className="w-full p-2 border rounded" rows={4} value={form.address} onChange={handleChange} />
        <div className="text-right text-lg font-semibold">Total: ₹{total.toFixed(2)}</div>
        <Button className="w-full bg-[#A3B18A] hover:bg-[#8DA57F] text-white" type="submit">
          Pay with Razorpay
        </Button>
      </form>
    </div>
  );
}