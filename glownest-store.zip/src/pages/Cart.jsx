import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function Cart() {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCartItems(storedCart);
  }, []);

  const removeItem = (index) => {
    const updated = [...cartItems];
    updated.splice(index, 1);
    setCartItems(updated);
    localStorage.setItem("cart", JSON.stringify(updated));
  };

  const total = cartItems.reduce((acc, item) => acc + parseFloat(item.price.replace("₹", "")), 0);

  if (cartItems.length === 0) return <div className="p-6 text-center text-gray-600">Your cart is empty.</div>;

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>
      {cartItems.map((item, idx) => (
        <div key={idx} className="flex items-center justify-between mb-4 p-4 rounded-lg shadow bg-white">
          <div className="flex items-center gap-4">
            <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-sm text-gray-500">{item.price}</p>
            </div>
          </div>
          <Button variant="destructive" onClick={() => removeItem(idx)}>Remove</Button>
        </div>
      ))}
      <div className="text-right text-lg font-semibold mt-6">Total: ₹{total.toFixed(2)}</div>
      <div className="mt-4 text-right">
        <Button className="bg-[#A3B18A] hover:bg-[#8DA57F] text-white" onClick={() => window.location.href='/checkout'}>
          Proceed to Checkout
        </Button>
      </div>
    </div>
  );
}