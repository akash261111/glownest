import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Home() {
  const testimonials = [
    {
      name: "Anjali R.",
      review: "GlowNest products are truly natural and feel amazing on my skin.",
    },
    {
      name: "Neha S.",
      review: "Fast delivery and beautiful packaging.",
    },
    {
      name: "Meera T.",
      review: "Exactly what I needed — responsibly and beautifully.",
    },
  ];

  return (
    <div className="bg-[#F5F3EA] min-h-screen flex flex-col items-center text-center px-6">
      <div className="py-10">
        <h1 className="text-4xl md:text-5xl font-bold text-[#333] mb-4">Welcome to GlowNest 🌿</h1>
        <p className="text-lg text-[#555] max-w-2xl mb-6">
          Discover natural wellness and eco-friendly beauty.
        </p>
        <Link to="/shop">
          <Button className="bg-[#A3B18A] hover:bg-[#8DA57F] text-white text-lg px-6 py-3 rounded-xl shadow">
            Shop Now
          </Button>
        </Link>
        <img src="/images/hero-glownest.jpg" alt="GlowNest Wellness" className="mt-10 max-w-xl w-full rounded-2xl shadow-lg" />
      </div>
      <div className="py-12 w-full bg-white">
        <h2 className="text-2xl font-bold mb-6 text-[#333]">What Our Customers Say</h2>
        <div className="grid gap-6 md:grid-cols-3 px-4 max-w-6xl mx-auto">
          {testimonials.map((t, idx) => (
            <div key={idx} className="bg-[#fff] p-6 rounded-xl shadow border border-[#e2e2e2]">
              <p className="text-[#555] mb-4">“{t.review}”</p>
              <p className="text-sm font-semibold text-[#333]">— {t.name}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}